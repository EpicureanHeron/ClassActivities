// Exporting an object containing all of our models

module.exports = {
  Note: require("./Note"),
  User: require("./User")
};
