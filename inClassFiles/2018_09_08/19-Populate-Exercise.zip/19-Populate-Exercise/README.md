# Populate

## Instructions

* Open `server.js` and update the `/populate` route to return Users populated with notes as JSON to the client.
