/*
    Create database
*/
DROP DATABASE IF EXISTS movies_DB;

CREATE DATABASE movies_DB;
USE movies_DB;

/*
    Create movies table
*/
CREATE TABLE movies (
 id INTEGER(10) AUTO_INCREMENT NOT NULL,
 title VARCHAR(50) NOT NULL,
 director VARCHAR(50) NOT NULL,
 year INTEGER(4) NOT NULL,
 length_minutes INTEGER(100) NOT NULL,
 PRIMARY KEY (id)
);

/*
    Create boxoffice table
*/
CREATE TABLE boxoffice (
 movie_id INTEGER(10) NOT NULL,
 rating DECIMAL(5,2) NOT NULL,
 domestic_sales INTEGER(15) NOT NULL,
 international_sales INTEGER(15) NOT NULL,
 PRIMARY KEY (movie_id)
);

/*
    Populate movie table
*/
INSERT INTO movies (title, director, year, length_minutes)
VALUES ("Toy Story", "John Lasseter", 1995, 81);

INSERT INTO movies (title, director, year, length_minutes)
VALUES ("A Bug's Life", "John Lasseter", 1998, 95);

INSERT INTO movies (title, director, year, length_minutes)
VALUES ("Toy Story 2", "John Lasseter", 1999, 93);

INSERT INTO movies (title, director, year, length_minutes)
VALUES ("Monsters, Inc.", "Pete Docter", 2001, 92);

INSERT INTO movies (title, director, year, length_minutes)
VALUES ("Finding Nemo", "Andrew Stanton", 2003, 107);

INSERT INTO movies (title, director, year, length_minutes)
VALUES ("The Incredibles", "Brad Bird", 2004, 116);

INSERT INTO movies (title, director, year, length_minutes)
VALUES ("Cars", "John Lasseter", 2006, 117);

INSERT INTO movies (title, director, year, length_minutes)
VALUES ("Ratatouille", "Brad Bird", 2007, 115);

INSERT INTO movies (title, director, year, length_minutes)
VALUES ("WALL-E", "Andrew Stanton", 2008, 104);

INSERT INTO movies (title, director, year, length_minutes)
VALUES ("Up", "Pete Docter", 2009, 101);

INSERT INTO movies (title, director, year, length_minutes)
VALUES ("Toy Story 3", "Lee Unkrich", 2010, 103);

INSERT INTO movies (title, director, year, length_minutes)
VALUES ("Cars 2", "John Lasseter", 2011, 120);

INSERT INTO movies (title, director, year, length_minutes)
VALUES ("Brave", "Brenda Chapman", 2012, 102);

INSERT INTO movies (title, director, year, length_minutes)
VALUES ("Monsters University", "Dan Scanlon", 2013, 110);

/* 
    Populate boxoffice table
*/
INSERT INTO boxoffice (movie_id, rating, domestic_sales, international_sales)
VALUES (5, 8.2,	380843261, 555900000);

INSERT INTO boxoffice (movie_id, rating, domestic_sales, international_sales)
VALUES (14, 7.4, 268492764,	475066843);

INSERT INTO boxoffice (movie_id, rating, domestic_sales, international_sales)
VALUES (8, 8, 206445654, 417277164);

INSERT INTO boxoffice (movie_id, rating, domestic_sales, international_sales)
VALUES (12, 6.4, 191452396,	368400000);

INSERT INTO boxoffice (movie_id, rating, domestic_sales, international_sales)
VALUES (3, 7.9,	245852179, 239163000);

INSERT INTO boxoffice (movie_id, rating, domestic_sales, international_sales)
VALUES (6, 8, 261441092, 370001000);

INSERT INTO boxoffice (movie_id, rating, domestic_sales, international_sales)
VALUES (9, 8.5,	223808164, 297503696);

INSERT INTO boxoffice (movie_id, rating, domestic_sales, international_sales)
VALUES (11, 8.4, 415004880,	648167031);

INSERT INTO boxoffice (movie_id, rating, domestic_sales, international_sales)
VALUES (1, 8.3,	191796233, 170162503);

INSERT INTO boxoffice (movie_id, rating, domestic_sales, international_sales)
VALUES (7, 7.2,	244082982, 217900167);

INSERT INTO boxoffice (movie_id, rating, domestic_sales, international_sales)
VALUES (10, 8.3, 293004164, 438338580);

INSERT INTO boxoffice (movie_id, rating, domestic_sales, international_sales)
VALUES (4, 8.1, 289916256, 272900000);

INSERT INTO boxoffice (movie_id, rating, domestic_sales, international_sales)
VALUES (2, 7.2, 162798565, 200600000);

INSERT INTO boxoffice (movie_id, rating, domestic_sales, international_sales)
VALUES (13, 7.2, 237283207,	301700000);

