SELECT * 
FROM movies_DB.movies;

SELECT * 
FROM movies_DB.movies
WHERE director = "John Lasseter";

SELECT * 
FROM movies_DB.movies
ORDER BY length_minutes;

SELECT * 
FROM movies_DB.movies
WHERE director = "John Lasseter"
ORDER BY title;

SELECT * 
FROM movies_DB.movies
WHERE year BETWEEN 1999 AND 2003;

SELECT title, year, domestic_sales, international_sales
FROM movies
INNER JOIN boxoffice
ON movies.id = boxoffice.movie_id
WHERE movies.title = "Cars";

SELECT title, year, domestic_sales + international_sales AS total_sales
FROM movies
INNER JOIN boxoffice
ON movies.id = boxoffice.movie_id;

SELECT SUM(domestic_sales) AS total_domestic_sales
FROM movies
INNER JOIN boxoffice
ON movies.id = boxoffice.movie_id;

SELECT AVG(domestic_sales) AS average_domestic_sales
FROM movies
INNER JOIN boxoffice
ON movies.id = boxoffice.movie_id;



INSERT INTO movies (title, director, year, length_minutes)
VALUES ("The Greatest Movie Ever", "Alex Hand", 2018, 500);

SELECT * FROM movies;

DELETE FROM movies
WHERE id = 16;

SELECT * FROM movies;

UPDATE  movies
SET title = "The Greatest Movie of Ever (Director's Cut)", length_minutes = 850
WHERE id = 15;

SELECT * FROM movies;

