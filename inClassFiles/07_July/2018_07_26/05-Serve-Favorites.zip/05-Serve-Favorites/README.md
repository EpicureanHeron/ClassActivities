# **Instructions**

* Create a website with four routes:
  * Home
  * Favorite Foods
  * Favorite Movies
  * Favorite CSS Frameworks
* Each route should be triggered by a different URL.
* Each route should display an HTML page listing your favorite three things of each.
* Be sure to use `fs` to serve your HTML files.

## Bonuses
* Have your home page have links to all of your other pages.
* DRY up your code by only having a single `readFile`
