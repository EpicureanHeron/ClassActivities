# README

As this is project week, there is no homework assignment for the testing unit. 

Base requirements for Project 2 can be found in [Requirements](Requirements/README.md), and additional suggestions regarding tests students should implement in developing their projects can be found in [Suggestions](Suggestions/README.md). 
