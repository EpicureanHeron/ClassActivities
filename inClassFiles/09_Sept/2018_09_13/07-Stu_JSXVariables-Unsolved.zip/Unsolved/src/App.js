import React from "react";
import JSXVariables from "./components/JSXVariables";

const App = () => <JSXVariables />;

export default App;
