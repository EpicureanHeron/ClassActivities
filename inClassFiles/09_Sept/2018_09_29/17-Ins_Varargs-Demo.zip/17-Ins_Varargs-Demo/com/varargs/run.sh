javac -cp ../../ *.java
java -cp ../../ com.varargs.Varargs
