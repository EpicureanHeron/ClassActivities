# Warm Up

## Instructions


FIRST:

    RENAME server.hard.js TO server.js

    OR 

    RENAME server.easy.js TO server.js

SECOND:

    - Your goal is to complete the routes in the server file so the site can display and edit the book data. Don't worry about the front end, just use MongoJS to finish the routes
