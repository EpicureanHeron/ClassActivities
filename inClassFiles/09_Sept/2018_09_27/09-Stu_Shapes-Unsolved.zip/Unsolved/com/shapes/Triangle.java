package com.shapes;

import java.lang.Math;

class Triangle {
  // Your implementation goes here.

  /**
   * @return The height of this triangle.
   */
  double getHeight () {
    // Replace SIDE_LENGTH with your side length variable.
    Math.sin(Math.toRadians(60)) * SIDE_LENGTH
  }
}
