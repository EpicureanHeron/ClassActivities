export { default } from "./SearchResults";
