export { default } from "./Footer";
