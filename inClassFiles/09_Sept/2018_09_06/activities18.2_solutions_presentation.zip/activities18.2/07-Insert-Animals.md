
BD/HW Input Updates

Annual/Monthly Field Removed

Annual/Monthly Field Removed

SELECT a.ACTIVITY_LOGS_ID, a.LOG_DATE, a.LOG_DATE_DATE, a.IP_ADDRESS, a.LOG_TYPE, a.PAGE_VIEWED, a.PHP_SESSION_ID, a.CUSTACCT, a.LEAD_SOURCE, a.OPTIMIZELY_ID, a.QUOTE_SOURCE, a.REFERRALOPTION_PARAM
FROM ACTIVITY_LOGS a
where log_date_date = '8/6/2018'
order by log_date DESC

vi:1*
sc:23*
cs:1536242516*
fs:1534778333*
pv:288*
exp:{100020400.{v.1000173708-g.{}}-100020473.{v.1000173868-g.{}}}
*ps:1536156006
*seg:{1000794.1}

Steven R. Chabinsky | White & Case LLP International Law Firm ...
Deputy Assistant Director, Cyber Division,
Federal Bureau of Investigations (FBI)
Chief Risk Officer of CrowdStrike

Shawn Henry is the president of CrowdStrike Services