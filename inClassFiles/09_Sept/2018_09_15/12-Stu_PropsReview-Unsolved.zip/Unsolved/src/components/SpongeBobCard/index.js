export { default } from "./SpongeBobCard";
