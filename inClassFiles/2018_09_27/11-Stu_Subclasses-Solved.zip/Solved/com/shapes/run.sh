# Run Test.java.
java -cp ../../ com.shapes.Test
