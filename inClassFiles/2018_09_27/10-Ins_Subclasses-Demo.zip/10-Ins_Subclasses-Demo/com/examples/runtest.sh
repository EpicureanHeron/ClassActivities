# Compile all and run test.
javac -cp ../../ *.java
java -cp ../../ com.examples.Test
