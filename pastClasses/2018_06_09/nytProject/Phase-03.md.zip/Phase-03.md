# New York Times Article Search - Phase 03

## Front-End Team

* Continue polishing the display of content in the HTML.

* Consider adding styling or other jQuery tricks.

* Consider using Bootswatch and/or Font Awesome to add more visual appeal

## Back-End Team

* Put in a hard-effort to deal with bugs. How can you handle missing fields?
